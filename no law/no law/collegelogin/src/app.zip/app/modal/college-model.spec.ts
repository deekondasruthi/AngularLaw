import { CollegeModel } from './college-model';

describe('CollegeModel', () => {
  it('should create an instance', () => {
    expect(new CollegeModel()).toBeTruthy();
  });
});
