export interface RegisterStudent {

    email:any
    name:any
    password:any;
    mobileNumber:any;

}


export interface makePayment{


    studentCourseId   :any
    studentId:any
    amount:any
    createdBy:any
}
