import { Component } from '@angular/core';

@Component({
  selector: 'app-opt',
  templateUrl: './opt.component.html',
  styleUrl: './opt.component.css'
})
export class OPTComponent {

  value:any
}
