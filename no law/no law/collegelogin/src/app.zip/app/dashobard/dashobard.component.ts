import { Component } from '@angular/core';

@Component({
  selector: 'app-dashobard',
  templateUrl: './dashobard.component.html',
  styleUrl: './dashobard.component.css'
})
export class DashobardComponent {

}
