import { Component } from '@angular/core';

@Component({
  selector: 'app-failure-payment',
  templateUrl: './failure-payment.component.html',
  styleUrl: './failure-payment.component.css'
})
export class FailurePaymentComponent {

}
