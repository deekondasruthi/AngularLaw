import { Component } from '@angular/core';

@Component({
  selector: 'app-success-payment',
  templateUrl: './success-payment.component.html',
  styleUrl: './success-payment.component.css'
})
export class SuccessPaymentComponent {

}
